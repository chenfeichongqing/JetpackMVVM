package com.github.chenfeichongqing.mvvmlib.base.network.manager

/**
 * 作者　: hegaojian
 * 时间　: 2020/5/2
 * 描述　: 网络变化实体类
 */
class NetState(
    var isSuccess: Boolean = true
)